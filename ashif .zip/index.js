// Accessing the camera feed
const videoElement = document.getElementById('camera-feed');

// Prompt the user for permission to use the camera
navigator.mediaDevices.getUserMedia({ video: true })
  .then((stream) => {
    videoElement.srcObject = stream;
  })
  .catch((error) => {
    console.error('Error accessing the camera:', error);
  });